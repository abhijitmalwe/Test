﻿
namespace PCPUI.Shared.Services.Authentication
{
    public interface IAuthenticationService
    {
        User SessionUser { get; }
        event EventHandler SessionUserUpdated;

        Task<User> RefreshSessionUserAsync();

        Task ResetPasswordAsync(string userId);

        Task Logout();

        Task<bool> IsUserAuthenticatedAsync();

        Task<bool> IsUserEmailVerified();
        Task<string> GetUserEmail();

        Task<string> GetUserID();
    }
}
