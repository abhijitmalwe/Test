﻿
using Microsoft.AspNetCore.Components;

namespace PCPUI.Shared.Services.Accounts
{
    public class AccountsService : IAccountsService
    {
        private readonly PCPAPIClient AccountsApi;

        private readonly HttpClient _httpClient;
        private readonly IErrorHandler ErrorHandler;

        private List<Account> _accounts = new();
        private Account _currentAccount = new();
        private List<AccountMemberDTO> _accountMembers = new();
        private List<AccountGroupMemberDTO> _accountRoles = new();

        public event EventHandler CurrentAccountUpdated;

        public event EventHandler HeaderUpdate;

        public List<Account> Accounts
        {
            get
            {
                return _accounts;
            }
        }

        public Account CurrentAccount
        {
            get
            {
                return _currentAccount;
            }
        }

        public List<AccountMemberDTO> AccountMembers
        {
            get
            {
                return _accountMembers;
            }
        }

        public List<AccountGroupMemberDTO> AccountsRole
        {
            get
            {
                return _accountRoles;
            }
        }

        public AccountsService(PCPAPIClient AccountsApi, 
            IErrorHandler ErrorHandler, 
            HttpClient httpClient)
        {
            this.AccountsApi = AccountsApi;
            this.ErrorHandler = ErrorHandler;
            this._httpClient = httpClient;
        }

        public async Task<IResult<List<Account>>> GetAllAsync()
        {
            try
            {
                var accounts = await AccountsApi.GetAccountsAsync();
                _accounts = accounts.ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return ErrorHandler.HandleException<List<Account>>(e);
            }
            return Result<List<Account>>.Success(_accounts);
        }

        public async Task<IResult<List<AccountMemberDTO>>> GetAccountMembersAsync()
        {
            try
            {
                ICollection<AccountMemberDTO> accountMembers = await AccountsApi.GetAccountMembersAsync(null,true, true, true);
                _accountMembers = accountMembers.ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return ErrorHandler.HandleException<List<AccountMemberDTO>>(e);
            }
            return Result<List<AccountMemberDTO>>.Success(_accountMembers);
        }

        public async Task<IResult<Account>> CreateAccount(CreateAccount createAccount)
        {
          Account account;
          try
          {
            //CreateAccount createAccount = new CreateAccount();
            //createAccount.Name = account;
            account = await AccountsApi.CreateAccountAsync(createAccount);
            _accounts.Add(account);
          }
          catch (Exception e)
          {
            Console.WriteLine(e.Message);
            return ErrorHandler.HandleException<Account>(e);
          }
          return Result<Account>.Success(account);
        }

        public async Task<List<AccountMemberInvitation>> GetInvitations()
        {
            return (await AccountsApi.GetMyAccountMemberInvitationsAsync()).ToList();
        }

        public async Task SetCurrentAccount(Account account)
        {
            _currentAccount = account;

            _httpClient.DefaultRequestHeaders.Remove("x-account-id");
            _httpClient.DefaultRequestHeaders.Add("x-account-id", CurrentAccount.Id);
        }

        protected virtual void OnCurrentAccountUpdatedEvent()
        {
            EventHandler handler = CurrentAccountUpdated;
            handler?.Invoke(this, EventArgs.Empty);
        }

        public void TriggerHeaderUpdateEvent(string Name)
        {
            OnHeaderUpdateEvent(Name);
        }

        protected async virtual void OnHeaderUpdateEvent(string Name)
        {
            EventHandler handler = HeaderUpdate;
            handler?.Invoke(Name, EventArgs.Empty);
        }

        public async Task<IResult<Account>> UpdateAccountAsync(Account account)
        {
            if(account != null)
            {
                var updateAccount = CreateUpdateAccountObject(account);
              _currentAccount = await AccountsApi.UpdateAccountAsync(updateAccount);
            }

            return Result<Account>.Success(_currentAccount);
        }

        public async Task<IResult<AccountMemberInvitation>> AcceptInvitationAsync(string id)
        {
            var invitation = await AccountsApi.AcceptAccountMemberInvitationAsync(id);
            return Result<AccountMemberInvitation>.Success(invitation);
        }

        public async Task<IResult<AccountMemberInvitation>> DeclineInvitationAsync(string id)
        {
            var invitation = await AccountsApi.DeclineAccountMemberInvitationAsync(id);
            return Result<AccountMemberInvitation>.Success(invitation);
        }

        public async Task<IResult<List<AccountGroupMemberDTO>>> GetAccountRolesAsync()
        {
            try
            {
                 _accountRoles = (await AccountsApi.GetAccountGroupsAsync()).ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return ErrorHandler.HandleException<List<AccountGroupMemberDTO>>(e);
            }
            return Result<List<AccountGroupMemberDTO>>.Success(_accountRoles);
        }

        public async Task<IResult<InternalDataProcessingEntity>> CreateAccoutnEntityAsync(InternalDataProcessingEntity request)
        {
            InternalDataProcessingEntity account;

            try
            {
                account = await AccountsApi.CreateAccountEntityAsync(request);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return ErrorHandler.HandleException<InternalDataProcessingEntity>(e);
            }

            return Result<InternalDataProcessingEntity>.Success(account);
        }

        public async Task<IResult<InternalDataProcessingEntity>> UpdateAccoutnEntityAsync(string id, InternalDataProcessingEntity request)
        {
            InternalDataProcessingEntity account;

            try
            {
                account = await AccountsApi.UpdateAccountEntityAsync(id, request);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return ErrorHandler.HandleException<InternalDataProcessingEntity>(e);
            }

            return Result<InternalDataProcessingEntity>.Success(account);
        }

        public async Task DeleteAccoutnEntityAsync(string id)
        {
            try
            {
                await AccountsApi.DeleteAccountEntityAsync(id);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public async Task<IResult<InternalDataProcessingEntity>> GetAccountEntityByIdAsync(string id)
        {
            InternalDataProcessingEntity entity;

            try
            {
                entity = await AccountsApi.GetAccountEntityAsync(id);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return ErrorHandler.HandleException<InternalDataProcessingEntity>(e);
            }

            return Result<InternalDataProcessingEntity>.Success(entity);
        }

        public async Task<IResult<List<InternalDataProcessingEntity>>> GetAccountEntitiesAsync()
        {
            List<InternalDataProcessingEntity> entity;

            try
            {
                entity = (await AccountsApi.GetAccountEntitiesAsync()).ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return ErrorHandler.HandleException<List<InternalDataProcessingEntity>>(e);
            }

            return Result<List<InternalDataProcessingEntity>>.Success(entity);
        }

        public async Task<CreateAccount> GetEmptyAccount()
        {
            CreateAccount createAccount = new CreateAccount();
            createAccount.Organization = new Organization();
            createAccount.Organization.OrganizationInfo = new OrganizationInfo();
            return createAccount;
        }

        public AccountCulture GetDefaultAccountCulture()
        {
            return CurrentAccount?.AccountCultures?.Where(x => x.Default == true).FirstOrDefault();
        }

        public async Task<IResult<List<AccountCulture>>> GetAccountCulturesAsync()
        {
            var culture = (await AccountsApi.GetAccountCulturesAsync()).ToList();
            return Result<List<AccountCulture>>.Success(culture);
        }

        public async Task<IResult<List<AccountCulture>>> SetAccountCulturesAsync(List<AccountCulture> accountCultureList)
        {
            var culture = await AccountsApi.SetAccountCulturesAsync(accountCultureList);
            return Result<List<AccountCulture>>.Success(culture.ToList());
        }

        public UpdateAccount CreateUpdateAccountObject(Account account)
        {
            UpdateAccount updateAccount = new UpdateAccount();
            updateAccount.Name = account.Name;
            if (account.System != true)
            {
                updateAccount.OrganizationInfo = new OrganizationInfo();
                updateAccount.OrganizationInfo = account.Organization.OrganizationInfo;
            }
                return updateAccount;
        }

        public bool IsSystemAccount()
        {
            if(CurrentAccount.System == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
